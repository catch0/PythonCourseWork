if num>100:
    print "that's a big number"
    if num<100: 
        print "that's a small number"