list = ["jim beam","woodford reserve", "jackdaniels", "old forester", "blah", "blah","blah","blah","blahblah","blah"]
if len(list)>50:
    print "big list"
else:
    print "small list"
    
        
    