string = "Comedy Bang Bang Comedy Bang Bang"
if len(string) > 50:
    print "Long Sentence"
else:
    print "short sentence"
        
    